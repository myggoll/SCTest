#include "xType.h"
#include "HelloWorldScene.h"

bool Block::init()
{
	blockSprite_ = Sprite::create("Icon.png");
	blockSprite_->setTag(Tag_MyBlock);
	this->addChild(blockSprite_);

	return true;
}

b2Fixture* Block::createBody_Box2d( b2World* _world, bool bMyBlock )
{
	return nullptr;
}


Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

void MyContactListener::BeginContact( b2Contact* contact )
{
	log("Begin Contact");
}

void MyContactListener::EndContact( b2Contact* contact )
{
	log("End Contact");
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    // add a "close" icon to exit the progress. it's an autorelease object
    auto closeItem = MenuItemImage::create(
                                           "CloseNormal.png",
                                           "CloseSelected.png",
                                           CC_CALLBACK_1(HelloWorld::menuCloseCallback, this));
    
	closeItem->setPosition(Vec2(origin.x + visibleSize.width - closeItem->getContentSize().width/2 ,
                                origin.y + closeItem->getContentSize().height/2));

    // create menu, it's an autorelease object
    auto menu = Menu::create(closeItem, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);

	//Create World
	b2Vec2 gravity = b2Vec2(0.0f, 0.0f);
	world_ = new b2World(gravity);
	world_->SetAllowSleeping(false);

	b2BodyDef screen_body_def;
	screen_body_def.position.Set(0.0f, 0.0f);
	screen_body_ = world_->CreateBody(&screen_body_def);

	world_->SetDebugDraw(&m_debugDraw);
	uint32 flags = 0;
	flags += b2Draw::e_shapeBit;
	flags += b2Draw::e_jointBit;
	flags += b2Draw::e_centerOfMassBit;
	flags += b2Draw::e_pairBit;
	m_debugDraw.SetFlags(flags);

	contactListener_ = new MyContactListener();
	world_->SetContactListener(contactListener_);


	this->schedule(schedule_selector(HelloWorld::tick));

	auto listener = EventListenerTouchOneByOne::create();
	listener->setSwallowTouches(true);
	listener->onTouchBegan = CC_CALLBACK_2(HelloWorld::onTouchBegan, this);
	listener->onTouchMoved = CC_CALLBACK_2(HelloWorld::onTouchMoved, this);
	listener->onTouchEnded = CC_CALLBACK_2(HelloWorld::onTouchEnded, this);
	listener->onTouchCancelled = CC_CALLBACK_2(HelloWorld::onTouchCancelled, this);

	EventDispatcher* dispatcher = Director::getInstance()->getEventDispatcher();
	dispatcher->addEventListenerWithSceneGraphPriority(listener, this);

	myBlock_ = Block::create();
	myBlock_->setPosition(100, 300);
	this->addChild(myBlock_);

	otherBlock_ = Block::create();
	otherBlock_->setPosition(600, 300);
	this->addChild(otherBlock_);
    
    return true;
}


void HelloWorld::menuCloseCallback(Ref* pSender)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WP8) || (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	MessageBox("You pressed the close button. Windows Store Apps do not implement a close button.","Alert");
    return;
#endif

    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}

void HelloWorld::draw( Renderer *renderer, const Mat4& transform, uint32_t flags )
{
	kmGLPushMatrix();
	kmGLLoadMatrix(&transform);
	GL::enableVertexAttribs(GL::VERTEX_ATTRIB_FLAG_POSITION);
	world_->DrawDebugData();
	kmGLPopMatrix();
}

void HelloWorld::tick( float dt )
{

}






