#include "xType.h"
#include "HelloWorldScene.h"


SkillBase* SkillBase::create(b2World *world_, b2Body* screen_body_)
{
	SkillBase *pRet = new SkillBase(world_, screen_body_);
	if ( pRet && pRet->init() )
	{
		pRet->autorelease();
		return pRet;
	}
	else
	{
		delete pRet;
		pRet = nullptr;
		return nullptr;
	}
}

bool SkillBase::init()
{
	//	�⺻ ��� ����
	Node* pNode = nullptr;
	pNode = CSLoader::createNode("Skill_Test.csb");
	if ( pNode == nullptr )
	{
		log("Error - Not Find .csb : Skill_Test.csb");
		return false;
	}
	this->addChild(pNode);

	pSprite_AtkArea_ = dynamic_cast<Sprite*>(pNode->getChildByName("Sprite_AtkArea"));
	pNode_body_ = pNode->getChildByName("Node_Body");
	pNode_Attack_ = pNode->getChildByName("Node_Attack");


	// ���� Ÿ�� ���� ����
	pActionTimeline_ = CSLoader::createTimeline("Skill_Test.csb");
	pActionTimeline_->setFrameEventCallFunc(CC_CALLBACK_1(SkillBase::onEventFrame, this));
	pNode->getActionManager()->addAction(pActionTimeline_, pNode, false);

	changeSkillState(eNormal);

	this->schedule(schedule_selector(SkillBase::tick));

	return true;
}

void SkillBase::onEventFrame( Ref* _pSender )
{
	EventFrame* pEventFrame = dynamic_cast<EventFrame*>(_pSender);
	if ( pEventFrame == nullptr )
		return;

	ActionTimeline* pActionTimeline = pEventFrame->getTimeline()->getActionTimeline();
	if ( pActionTimeline == nullptr )
		return;

	std::string str = pEventFrame->getEvent();
	log("onEventFrame : %s", str.c_str());

	//	���� ������ �� �𸣰����� Ÿ�Ӷ��� �������� Event ȣ���� �Ͼ�°� ����
// 	if ( pActionTimeline->getCurrentFrame() != pEventFrame->getFrameIndex() )
// 	{
// 		debugf(AutoText("Unknown - onEventFrame_Unit %s"), str.c_str());
// 		return;
// 	}
// 
// 	debugf(AutoText("Call - onEventFrame_Unit %s"), str.c_str());
// 
// 	if ( str == "Change_Idle" )
// 	{
// 		debugf(AutoText("Success - onEventFrame_Unit %s"), str.c_str());
// 		changeNodeState(Idle);
// 	}
}

void SkillBase::changeSkillState( SkillState _ChangeNodeState )
{
	if( _ChangeNodeState == eNone || _ChangeNodeState == eSkillStateMax)
	{
		log("SkillBase::changeSkillState Error 0x%x", _ChangeNodeState);
		return;
	}

	//	Auto Looping
	bool Looping = false;
	switch ( _ChangeNodeState )
	{
	case SkillState::eNormal:
		{
			Looping = true;
			pNode_body_->setVisible(true);
			pSprite_AtkArea_->setVisible(false);
			pNode_Attack_->setVisible(false);
			pActionTimeline_->gotoFrameAndPlay(1, 41, 1, Looping);
		} break;
	case SkillState::eAttack:
		{
			pNode_body_->setVisible(false);
			pSprite_AtkArea_->setVisible(false);
			pNode_Attack_->setVisible(true);
			pActionTimeline_->gotoFrameAndPlay(42, 82, 42, Looping);
		} break;
	}

	//	Ȱ��ȭ �� �ִ� ����
	eState_ = _ChangeNodeState;
}

bool SkillBase::initBox2dData()
{
	Sprite* bodySpr = dynamic_cast<Sprite*>(pNode_body_->getChildByName("Sprite_Body"));
	Vec2 bodyPos = pNode_body_->convertToWorldSpace(bodySpr->getPosition());
	bodyPos = this->getParent()->convertToNodeSpace(bodyPos);

	b2BodyDef block_body_def;
	block_body_def.type = b2_dynamicBody;
	block_body_def.position.Set( SCREEN_TO_BOX2D(bodyPos.x),SCREEN_TO_BOX2D(bodyPos.y));
	block_body_def.userData = this;

	pBody_BodyNode = world_->CreateBody(&block_body_def);

	b2PolygonShape block_polygon;
	block_polygon.SetAsBox( SCREEN_TO_BOX2D(bodySpr->getContentSize().width)/2,SCREEN_TO_BOX2D(bodySpr->getContentSize().height)/2);
	b2FixtureDef block_fixture_def;
	block_fixture_def.shape = &block_polygon;
 	block_fixture_def.filter.categoryBits = ProjectileCategory_My;
 	block_fixture_def.filter.maskBits = 0xFFFF^(BlockCategory_My | ProjectileCategory_My | SkillAttackAreaCategory_My) ;
	pBody_BodyNode->CreateFixture(&block_fixture_def);

	return true;
}





Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    // add a "close" icon to exit the progress. it's an autorelease object
    auto closeItem = MenuItemImage::create(
                                           "CloseNormal.png",
                                           "CloseSelected.png",
                                           CC_CALLBACK_1(HelloWorld::menuCloseCallback, this));
    
	closeItem->setPosition(Vec2(origin.x + visibleSize.width - closeItem->getContentSize().width/2 ,
                                origin.y + closeItem->getContentSize().height/2));

    // create menu, it's an autorelease object
    auto menu = Menu::create(closeItem, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);

	b2Vec2 gravity = b2Vec2(0.0f, 0.0f);
	world_ = new b2World(gravity);
	world_->SetAllowSleeping(false);

	b2BodyDef screen_body_def;
	screen_body_def.position.Set(0.0f, 0.0f);
	screen_body_ = world_->CreateBody(&screen_body_def);

	world_->SetDebugDraw(&m_debugDraw);
	uint32 flags = 0;
	flags += b2Draw::e_shapeBit;
	flags += b2Draw::e_jointBit;
	flags += b2Draw::e_centerOfMassBit;
	flags += b2Draw::e_pairBit;
	m_debugDraw.SetFlags(flags);

	contactListener_ = new MyContactListener();
	world_->SetContactListener(contactListener_);


	my_block_ = Block::create();
	my_block_->setPosition(100, 300);
	my_block_->setTag(Tag_MyBlock);
	this->addChild(my_block_);
	my_block_->initBox2dData(world_, true);

	other_block_ = Block::create();
	other_block_->setPosition(600, 300);
	my_block_->setTag(Tag_OtherBlock);
	this->addChild(other_block_);
	other_block_->initBox2dData(world_, false);


	this->schedule(schedule_selector(HelloWorld::tick));

	auto listener = EventListenerTouchOneByOne::create();
	listener->setSwallowTouches(true);
	listener->onTouchBegan = CC_CALLBACK_2(HelloWorld::onTouchBegan, this);
	listener->onTouchMoved = CC_CALLBACK_2(HelloWorld::onTouchMoved, this);
	listener->onTouchEnded = CC_CALLBACK_2(HelloWorld::onTouchEnded, this);
	listener->onTouchCancelled = CC_CALLBACK_2(HelloWorld::onTouchCancelled, this);

	EventDispatcher* dispatcher = Director::getInstance()->getEventDispatcher();
	dispatcher->addEventListenerWithSceneGraphPriority(listener, this);




    SkillBase* pTest = SkillBase::create(world_, screen_body_);
	pTest->setName("TestSkill");
	//pTest->setPosition(my_blockSprite_->getPosition());
	pTest->setPosition(300,300);
	pTest->setTag(Tag_Skill);
	this->addChild(pTest);
	pTest->initBox2dData();

    
    return true;
}


void HelloWorld::menuCloseCallback(Ref* pSender)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WP8) || (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	MessageBox("You pressed the close button. Windows Store Apps do not implement a close button.","Alert");
    return;
#endif

    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}

void HelloWorld::tick( float dt )
{
	my_block_->syncBox2DPos();
	other_block_->syncBox2DPos();

	SkillBase* pTest = dynamic_cast<SkillBase*>(this->getChildByName("TestSkill"));
	pTest->syncBox2DPos();

	world_->Step(dt, 8, 3);

	for(b2Body *b = world_->GetBodyList(); b; b=b->GetNext()) {
		if (b->GetUserData() != NULL) {
			Node *node = (Node*)b->GetUserData();
			node->setPosition( node->getParent()->convertToNodeSpace( Vec2( BOX2D_TO_SCREEN(b->GetPosition().x), BOX2D_TO_SCREEN(b->GetPosition().y) ) ) );
			node->setRotation(-1 * CC_RADIANS_TO_DEGREES(b->GetAngle()));
		}
	}
}

void HelloWorld::draw( Renderer *renderer, const Mat4& transform, uint32_t flags )
{
	kmGLPushMatrix();
	kmGLLoadMatrix(&transform);
	GL::enableVertexAttribs(GL::VERTEX_ATTRIB_FLAG_POSITION);
	world_->DrawDebugData();
	kmGLPopMatrix();
}

void HelloWorld::onTouchEnded( Touch *pTouch, Event *pEvent )
{
	Vec2 touchPos = this->convertTouchToNodeSpace(pTouch);
	SkillBase* pTest = dynamic_cast<SkillBase*>(this->getChildByName("TestSkill"));

	MoveTo* pMoveTo = MoveTo::create(pTest->getPosition().distance(touchPos)/200, touchPos);
	pTest->runAction(pMoveTo);
}

void MyContactListener::BeginContact( b2Contact* contact )
{
	if( contact->GetFixtureA()->IsSensor() || contact->GetFixtureB()->IsSensor() )
	{
		return;
	}

	Node* NodeA = (Node*)contact->GetFixtureA()->GetBody()->GetUserData();
	Node* NodeB = (Node*)contact->GetFixtureB()->GetBody()->GetUserData();

	if( NodeA->getTag() == Tag_Skill )
	{
		NodeA->stopAllActions();
		static_cast<SkillBase*>(NodeA)->attack();
	}

	if( NodeB->getTag() == Tag_Skill )
	{
		NodeB->stopAllActions();
		static_cast<SkillBase*>(NodeB)->attack();
	}


	log("Begin Contact");
}

void MyContactListener::EndContact( b2Contact* contact )
{
	log("End Contact");
}
