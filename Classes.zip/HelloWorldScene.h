#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "GLES-Render.h"

#define PTM_RATIO   32.0f

USING_NS_CC;
USING_NS_TIMELINE;

#define Tag_MyBlock   1
#define Tag_OtherBlock 2
#define Tag_Skill 3

#define BlockCategory_My 0x0001
#define BlockCategory_Other 0x0002 
#define ProjectileCategory_My 0x0004
#define ProjectileCategory_Other 0x0008
#define SkillAttackAreaCategory_My 0x0020
#define SkillAttackAreaCategory_Other 0x0040

#define SCREEN_TO_BOX2D(fVal) (fVal/PTM_RATIO)
#define BOX2D_TO_SCREEN(fVal) (fVal*PTM_RATIO)

class MyContactListener : public b2ContactListener
{
public:
	MyContactListener()
	{}
	~MyContactListener(){}
	virtual void BeginContact(b2Contact* contact);
	virtual void EndContact(b2Contact* contact);
	virtual void PreSolve(b2Contact* contact, const b2Manifold* oldManifold){}
	virtual void PostSolve(b2Contact* contact, const b2Manifold* oldManifold){}
};

class SkillBase : public Node
{
public:
	enum SkillState
	{
		eNone,
		eNormal,
		eAttack,
		eSkillStateMax
	};

	SkillBase(b2World *world_, b2Body* screen_body_)
		: world_(world_),
		pScreenBody_(screen_body_),
		eState_(eNone),
		pSprite_AtkArea_(nullptr),
		pNode_body_(nullptr),
		pNode_Attack_(nullptr),
		pActionTimeline_(nullptr)
	{

	}
	virtual ~SkillBase(){}

	static SkillBase* create(b2World *world_, b2Body* screen_body_);

	virtual bool init();

	void changeSkillState( SkillState _ChangeNodeState );

	bool initBox2dData();

	void syncBox2DPos()
	{
		pBody_BodyNode->SetTransform( b2Vec2( SCREEN_TO_BOX2D(this->getPositionX()), SCREEN_TO_BOX2D(this->getPositionY())), pBody_BodyNode->GetAngle());
	}

	void attack()
	{
// 		world_->DestroyBody(pBody_BodyNode);
// 
// 		Vec2 bodyPos = pNode_body_->convertToWorldSpace(pSprite_AtkArea_->getPosition());
// 		bodyPos = this->getParent()->convertToNodeSpace(bodyPos);
// 		b2Vec2 pos(bodyPos.x, bodyPos.y);
// 		pos.x = SCREEN_TO_BOX2D(pos.x);
// 		pos.y = SCREEN_TO_BOX2D(pos.y);
// 
// 		b2PolygonShape attackaread_shape;
// 		attackaread_shape.SetAsBox( SCREEN_TO_BOX2D(pSprite_AtkArea_->getScaleX())/2,
// 			SCREEN_TO_BOX2D(pSprite_AtkArea_->getScaleY())/2, pos, CC_DEGREES_TO_RADIANS(this->getRotation()) );
// 
// 		b2FixtureDef fd;
// 		fd.shape = &attackaread_shape;
// 		fd.isSensor = true;
// 		pScreenBody_->CreateFixture(&fd);

		changeSkillState(eAttack);
	}

private:
	void onEventFrame(Ref* _pSender);
	void tick( float dt )
	{

	}

private:
	SkillState eState_;

	Sprite* pSprite_AtkArea_;
	Node* pNode_body_;
	Node* pNode_Attack_;

	b2Body* pBody_BodyNode;

	ActionTimeline* pActionTimeline_;

	b2World *world_;
	b2Body *pScreenBody_;
};

class Block : public Node
{
public:
	CREATE_FUNC(Block);

	virtual bool init()
	{
		blockSprite = Sprite::create("Icon.png");
		blockSprite->setTag(Tag_MyBlock);
		this->addChild(blockSprite);

		return true;
	}

	bool initBox2dData(b2World* _world, bool bMyBlock)
	{
		b2BodyDef block_body_def;
		block_body_def.type = b2_dynamicBody;
		block_body_def.position.Set( SCREEN_TO_BOX2D(this->getPositionX()), SCREEN_TO_BOX2D(this->getPositionY()) );
		block_body_def.userData = this;
		blockBody = _world->CreateBody(&block_body_def);

		b2PolygonShape block_polygon;
		block_polygon.SetAsBox( SCREEN_TO_BOX2D(blockSprite->getContentSize().width)/2,
			SCREEN_TO_BOX2D(blockSprite->getContentSize().height)/2);
		b2FixtureDef block_fixture_def;
		block_fixture_def.shape = &block_polygon;
		if( bMyBlock )
		{
			block_fixture_def.filter.categoryBits = BlockCategory_My;
			block_fixture_def.filter.maskBits = 0xFFFF^(BlockCategory_My | ProjectileCategory_My | SkillAttackAreaCategory_My) ;
		}
		else
		{
			block_fixture_def.filter.categoryBits = BlockCategory_Other;
			block_fixture_def.filter.maskBits = 0xFFFF^(BlockCategory_Other | ProjectileCategory_Other | SkillAttackAreaCategory_Other) ;
		}
		blockBody->CreateFixture(&block_fixture_def);

		return true;
	}

	Block()
		: blockSprite(nullptr)
		, blockBody(nullptr)
	{

	}

	virtual ~Block(){}

	void syncBox2DPos()
	{
		blockBody->SetTransform( b2Vec2( SCREEN_TO_BOX2D(this->getPositionX()), SCREEN_TO_BOX2D(this->getPositionY())), blockBody->GetAngle());
	}

private:
	Sprite* blockSprite;
	b2Body* blockBody;
};


class HelloWorld : public cocos2d::Layer
{
public:
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
    CREATE_FUNC(HelloWorld);

	HelloWorld()
		: world_(nullptr),
		screen_body_(nullptr),
		contactListener_(nullptr),
		m_debugDraw(PTM_RATIO)
	{

	}

private:
	void tick( float dt );

	virtual bool onTouchBegan(Touch *pTouch, Event *pEvent){return true;}
	virtual void onTouchMoved(Touch *pTouch, Event *pEvent){}
	virtual void onTouchEnded(Touch *pTouch, Event *pEvent);
	virtual void onTouchCancelled(Touch *pTouch, Event *pEvent){}
	virtual void draw(Renderer *renderer, const Mat4& transform, uint32_t flags);


private:
	b2World *world_;
	b2Body *screen_body_;
	MyContactListener *contactListener_;
	GLESDebugDraw m_debugDraw;

	Block* my_block_;
	Block* other_block_;
};

#endif // __HELLOWORLD_SCENE_H__
