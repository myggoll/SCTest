﻿#ifndef		__XENESIS__MINI__TYPES__
#define		__XENESIS__MINI__TYPES__

//	@@	[11/24/2014 KimJuneYoung] - 멀티 플렛폼 지원하기 위한 타입
typedef		long						s64;							//!<	부호 있는 8byte형
typedef		int							s32;							//!<	부호 있는 4byte형
typedef		short						s16;							//!<	부호 있는 2byte형
typedef		char						s8;								//!<	부호 있는 1byte형

typedef		unsigned long				u64;							//!<	부호 없는 8byte형
typedef		unsigned int				u32;							//!<	부호 없는 4byte형
typedef		unsigned short				u16;							//!<	부호 없는 2byte형
typedef		unsigned char				u8;								//!<	부호 없는 1byte형

typedef		float						f32;							//!<	부동 소수점 4byte형
typedef		double						f64;							//!<	부동 소수점 8byte형
//	@@	//

typedef		u32							uint;
typedef		s32							sint;

typedef		char						uchar;							//!<	1바이트 문자형
typedef		unsigned short				uchar_t;						//!<	2바이트 문자형

#ifndef IN
#define IN
#endif

#ifndef OUT
#define OUT
#endif

#ifndef MAX_PATH
#define MAX_PATH 260
#endif








#endif	//	__XENESIS__MINI__TYPES__